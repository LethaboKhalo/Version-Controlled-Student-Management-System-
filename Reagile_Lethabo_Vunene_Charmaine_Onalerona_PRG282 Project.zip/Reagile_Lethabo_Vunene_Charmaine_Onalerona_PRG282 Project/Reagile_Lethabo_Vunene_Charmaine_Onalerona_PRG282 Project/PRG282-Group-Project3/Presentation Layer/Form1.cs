﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using UpdatedProject.Data_Layer;
using System.Text.RegularExpressions;
using UpdatedProject.Business_Layer;

namespace UpdatedProject
{
    public partial class Form1 : Form
    {
        private Filehandler fileHandler = new Filehandler();

        public Form1()
        {
            InitializeComponent();
        }

        // Button click event to add a new student
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (ValidateInputsForAdd())
            {
                try
                {
                    string id = txtStudentID.Text;
                    string name = txtStudentName.Text;
                    int age = int.Parse(txtStudentAge.Text);
                    string course = txtStudentCourse.Text;

                    // Add student to file
                    fileHandler.AddStudent(id, name, age, course);
                    DisplayAllStudents();
                    MessageBox.Show("Student added successfully!", "Success");

                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error adding student: {ex.Message}", "Error");
                }
            }
        }

        // Button click event to update existing student information
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ValidateInputsForUpdate())
            {
                try
                {
                    string id = txtStudentID.Text;
                    string newName = txtStudentName.Text;
                    int newAge = int.Parse(txtStudentAge.Text);
                    string newCourse = txtStudentCourse.Text;

                    // Update student information in the file
                    fileHandler.UpdateStudent(id, newName, newAge, newCourse);
                    DisplayAllStudents();
                    MessageBox.Show("Student updated successfully!", "Success");

                    // Clear the textboxes and reset the form
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating student: {ex.Message}", "Error");
                }
            }
        }

        // Validation for adding a new student
        private bool ValidateInputsForAdd()
        {
            if (string.IsNullOrWhiteSpace(txtStudentID.Text) ||
                string.IsNullOrWhiteSpace(txtStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtStudentAge.Text) ||
                string.IsNullOrWhiteSpace(txtStudentCourse.Text))
            {
                MessageBox.Show("All fields are required.", "Validation Error");
                return false;
            }

            if (!int.TryParse(txtStudentAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Please enter a valid positive integer for age.", "Validation Error");
                return false;
            }

            if (!Regex.IsMatch(txtStudentName.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Student name should only contain letters.", "Validation Error");
                return false;
            }

            // Check for duplicate Student ID only when adding a new student
            if (IsDuplicateStudentID(txtStudentID.Text))
            {
                MessageBox.Show("Student ID already exists. Please enter a unique ID.", "Validation Error");
                return false;
            }

            return true;
        }

        // Validation for updating an existing student
        private bool ValidateInputsForUpdate()
        {
            if (string.IsNullOrWhiteSpace(txtStudentID.Text) ||
                string.IsNullOrWhiteSpace(txtStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtStudentAge.Text) ||
                string.IsNullOrWhiteSpace(txtStudentCourse.Text))
            {
                MessageBox.Show("All fields are required.", "Validation Error");
                return false;
            }

            if (!int.TryParse(txtStudentAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Please enter a valid positive integer for age.", "Validation Error");
                return false;
            }

            if (!Regex.IsMatch(txtStudentName.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Student name should only contain letters.", "Validation Error");
                return false;
            }

            // No need to check for duplicate ID when updating
            return true;
        }

        // Clears all input fields and resets the form
        private void ClearFields()
        {
            txtStudentID.Text = "";
            txtStudentName.Text = "";
            txtStudentAge.Text = "";
            txtStudentCourse.Text = "";
            txtStudentID.ReadOnly = false;
            btnUpdate.Enabled = false;
        }

        private void ClearInputs()
        {
            txtStudentID.Text = string.Empty;
            txtStudentName.Text = string.Empty;
            txtStudentAge.Text = string.Empty;
            txtStudentCourse.Text = string.Empty;
            txtStudentID.Enabled = true; // Enable Student ID textbox for adding new students
        }


        // Validates input fields for correctness
        private bool ValidateInputs()
        {
            // Check if any field is empty
            if (string.IsNullOrWhiteSpace(txtStudentID.Text) ||
                string.IsNullOrWhiteSpace(txtStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtStudentAge.Text) ||
                string.IsNullOrWhiteSpace(txtStudentCourse.Text))
            {
                MessageBox.Show("All fields are required.", "Validation Error");
                return false;
            }

            // Check if the age is a positive integer
            if (!int.TryParse(txtStudentAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Please enter a valid positive integer for age.", "Validation Error");
                return false;
            }

            // Validate that the student name contains only letters (no digits or special characters)
            if (!Regex.IsMatch(txtStudentName.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Student name should only contain letters.", "Validation Error");
                return false;
            }

            // Check for duplicate Student ID
            if (IsDuplicateStudentID(txtStudentID.Text))
            {
                MessageBox.Show("Student ID already exists. Please enter a unique ID.", "Validation Error");
                return false;
            }

            return true;
        }


        // Button click event to delete a student
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string id = dataGridView1.SelectedRows[0].Cells["StudentID"].Value.ToString();
                    fileHandler.DeleteStudent(id);
                    DisplayAllStudents();
                    MessageBox.Show("Student deleted successfully!", "Success");
                }
                else
                {
                    MessageBox.Show("Please select a student to delete.", "Warning");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting student: {ex.Message}", "Error");
            }
        }

        // Displays all students in DataGridView
        private void dvgsDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                // Clear any existing columns and rows in the DataGridView
                dataGridView1.DataSource = null;
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();

                // Retrieve all students and bind to the DataGridView
                DisplayAllStudents();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error displaying students: {ex.Message}", "Error");
            }
        }

        // Displays all students from the file
        private void DisplayAllStudents()
        {
            try
            {
                var studentsList = fileHandler.GetAllStudents();
                if (studentsList != null && studentsList.Count > 0)
                {
                    var bindingSource = new BindingSource
                    {
                        DataSource = studentsList
                    };
                    dataGridView1.DataSource = bindingSource;

                    // Automatically adjust the column widths
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                else
                {
                    MessageBox.Show("No student data available.", "Info");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading students: {ex.Message}", "Error");
            }
        }

        // Button click event to generate and display the summary
        private void btnViewSummary_Click(object sender, EventArgs e)
        {
            GenerateSummary();
        }


        // Method to generate and display the summary
        private void GenerateSummary()
        {
            try
            {
                // Retrieve all students
                var studentsList = fileHandler.GetAllStudents();

                if (studentsList == null || studentsList.Count == 0)
                {
                    LblSummary.Text = "No students available to generate summary.";
                    return;
                }

                // Calculate total number of students
                int totalStudents = studentsList.Count;

                // Calculate average age
                double averageAge = studentsList.Average(student => student.Age);

                // Create summary string
                string summary = $"Total Students: {totalStudents}\nAverage Age: {averageAge:F2}";

                // Display the summary on the label
                LblSummary.Text = summary;

                // Save the summary to a file
                SaveSummaryToFile(summary);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating summary: {ex.Message}", "Error");
            }
        }

        
        // Method to save the summary to a text file
        private void SaveSummaryToFile(string summary)
        {
            try
            {
                string filePath = "summary.txt";
                File.WriteAllText(filePath, summary);
                MessageBox.Show($"Summary saved to {filePath}", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving summary to file: {ex.Message}", "Error");
            }
        }

        // Handles cell click to populate fields with selected student's data
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells[0].Value != null)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                txtStudentID.Text = row.Cells["StudentID"].Value.ToString();
                txtStudentName.Text = row.Cells["StudentName"].Value.ToString();
                txtStudentAge.Text = row.Cells["Age"].Value.ToString();
                txtStudentCourse.Text = row.Cells["Course"].Value.ToString();

                // Make the ID textbox read-only for updates
                txtStudentID.ReadOnly = true;

                // Enable the Update button
                btnUpdate.Enabled = true;
            }
        }



        // Checks if the entered Student ID already exists
        private bool IsDuplicateStudentID(string studentID)
        {
            try
            {
                // Retrieve the current list of students
                var studentsList = fileHandler.GetAllStudents();

                // Check if any student has the same ID
                return studentsList.Any(student => student.StudentID.Equals(studentID, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking for duplicates: {ex.Message}", "Error");
                return false;
            }
        }


        private void LblSummary_Click(object sender, EventArgs e)
        {

        }
    }

}